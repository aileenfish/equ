﻿//Copyright (C) KONICA MINOLTA, INC.  All rights reserved. 2018

#pragma once

#ifndef KMAPI
#define KMAPI __stdcall
#endif //KMAPI
